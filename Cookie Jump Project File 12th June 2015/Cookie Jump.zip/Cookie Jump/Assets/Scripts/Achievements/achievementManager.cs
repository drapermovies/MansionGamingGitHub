﻿//Made by Joel Draper for MansionGaming
using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class achievementManager : MonoBehaviour {

    public Text text;
    public Text text1;

    public GameObject achievementCanvas;
    public GameObject AchievSFX;

    private string achievementName;
    public float achievDisplayTime;
    private string achievementReward;

    public ScoreBasics score;
    public coinManager coin;

    private bool achiev1 = false;
    private bool achiev2 = false;
    public bool spender = false;

	void Start () {

	}
	
	void Update () {
        if (score.score > 20 && !achiev1)
        {
            Debug.Log("achievement 1 achieved"); 
            achievementName = "Twenty is Plenty";
            achievementReward = "10 gold coins";
            coin.gold += 10;
            StartCoroutine (achievement());
            achiev1 = true;
        }
        if(score.score > 50 && !achiev2)
        {
            Debug.Log("achievement 2 achieved");
            achievementName = "Half century";
            achievementReward = "20 gold coins";
            coin.gold += 50;
            StartCoroutine (achievement());
            achiev2 = true;
        }
        if(spender)
        {
            Debug.Log("achievement 3 achieved");
            achievementName = "Spender";
            achievementReward = " ";
            StartCoroutine(achievement());
        }
	}

    IEnumerator achievement()
    {
        Debug.Log("achievement coroutine started");
        achievementCanvas.SetActive(true);
        AchievSFX.GetComponent<AudioSource>().Play();
        text.text = achievementName;
        text1.text = achievementReward;
        yield return new WaitForSeconds(achievDisplayTime);
        achievementCanvas.SetActive(false);
        AchievSFX.GetComponent<AudioSource>().Stop();
        Debug.Log("achievement audio should stop");
        StopCoroutine (achievement());
        Debug.Log("coroutine stopped");
    }
}

﻿using UnityEngine;
using System.Collections;

public class logoScene : MonoBehaviour {

	void Start () {
        StartCoroutine(sceneLogo());
	}

    IEnumerator sceneLogo()
    {
        yield return new WaitForSeconds(5);
        Application.LoadLevel(1);
    }

}

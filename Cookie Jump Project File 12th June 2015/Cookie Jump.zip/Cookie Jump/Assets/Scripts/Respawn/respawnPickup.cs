﻿using UnityEngine;
using System.Collections;

public class respawnPickup : MonoBehaviour {

    public RespawnBasics respawn;

    public GameObject rPickupSFX;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.name == "Player")
        {
            respawn.respawnsLeft += 1; //When player picks up the object, they get 1 respawn
            Destroy(gameObject); //When the player picks up the object, destroy the object
        }
    }

    void OnDestroy()
    {
        rPickupSFX.GetComponent<AudioSource>().Play(); //When object is destroyed, play sound
    }
}

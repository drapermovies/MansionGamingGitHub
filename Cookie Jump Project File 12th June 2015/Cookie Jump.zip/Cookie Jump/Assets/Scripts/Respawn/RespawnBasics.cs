﻿//Made by Joel Draper for MansionGaming
using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.Advertisements;

public class RespawnBasics : MonoBehaviour {

    public Text text; //Allows us to display respawns (just to make sure it is working) 

    public float respawnDelay; //Easy input of time to wait before respawn

    public GameObject currentCheckpoint;
    public GameObject gameOverCanvas;
    public GameObject gameCanvas;
    public GameObject achievementCanvas;

    public ScoreBasics scoreM;
    public HealthAddon healthAdd;
    public PlayerFunctions playerF;
    public AudioManager audioM;

    public GameObject player;

    public int respawnsLeft;

    //public bool isDead;

    void Awake()
    {
        if (Advertisement.isSupported)
        {
            Advertisement.allowPrecache = true;
            Advertisement.Initialize("42576", false);
        }
        else
        {
            Debug.Log("Platform not supported");
        }
    }

	void Start () { 
        text.text = respawnsLeft.ToString();

        respawnsLeft = PlayerPrefs.GetInt("respawnsLeft", 0);

        if (respawnsLeft < 0)
        {
            respawnsLeft = 0;
            Debug.Log("respawns reset");
        }
    }

    void Update() {
        /*if (respawnsLeft <= 0)
        {
            respawnsLeft = 1;
            Debug.Log("respawns reset");
        }*/

        if (respawnsLeft < 0)
        {
            //playerF.canJump = false;
            audioM.muteAudio = true;
            playerF.isActive = false;
            gameCanvas.SetActive(false);
            achievementCanvas.SetActive(false);
            scoreM.deathScore = scoreM.score;
            //isDead = true;
            Time.timeScale = 0f;
            Advertisement.Show(null, new ShowOptions
            {
                pause = true,
                resultCallback = result =>
                {
                    Debug.Log("ad is shown");
                    gameOverCanvas.SetActive(true);
                }
            });
        }

        text.text = respawnsLeft.ToString();
    }

    void OnDestroy()
    {
        PlayerPrefs.SetInt("respawnsLeft", respawnsLeft);
        scoreM.score = scoreM.deathScore;
    }

    public void deathRespawn()
    {

        if (respawnsLeft >= 0)
        {
            Debug.Log("player respawned");
            player.transform.position = currentCheckpoint.transform.position;
            StartCoroutine(respawnPlayer()); //When player dies, the coroutine plays 
        }

        //Destroy(player.gameObject); //When the player dies, they are destroyed
        
    }

    IEnumerator respawnPlayer()
    {
        healthAdd.resetHealth();
        yield return new WaitForSeconds(respawnDelay);
        respawnsLeft -= 1; //When the player dies, they lose a respawn 
        scoreM.score -= 30; //When player dies, they lose 30 score points
    }

   /* IEnumerator deadPlayer()
    {
        scoreM.score = scoreM.deathScore; //The score when the player dies, is their final score
        yield return new WaitForSeconds(1); 
        Application.LoadLevel(1); //When player has no respawns left, the next level loads
    }*/
}

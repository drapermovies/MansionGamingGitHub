﻿using UnityEngine;
using System.Collections;

public class buttons : MonoBehaviour
    
{
    public bool paused = false;

    public pauseState pauseS;
    public PlayerFunctions player;

    public GameObject guiCanvas;
    public GameObject pauseMenuCanvas;

    public void pauseState ()
    {
        Time.timeScale = 0f; //On button click, stop time 
        paused = true; //This is intended for audio sources, so I can pause audio sources if the game is paused
        Debug.Log("paused button clicked");
        if (paused)
        {
            pauseMenuCanvas.SetActive(true);
            guiCanvas.SetActive(false);
            pauseS.paused = true;
        }
    }

    public void resume ()
    {
        Debug.Log("resume button is clicked");
        paused = false;
        Time.timeScale = 1f;
        pauseMenuCanvas.SetActive(false);
        guiCanvas.SetActive(true);
    }

    public void creditsButton ()
    {
        Debug.Log("credits button is clicked");
        Application.LoadLevel("Tech Demo Credits");
    }

    public void restartButton ()
    {
        player.isActive = false;
        Debug.Log("restart");
        Application.LoadLevel(1);
    }

    public void backFromCredits ()
    {
        Debug.Log("back from credits");
        Application.LoadLevel(1);
    }

    public void storeButton ()
    {
        Debug.Log("load store");
        Application.LoadLevel("Tech Demo Store");
    }
}

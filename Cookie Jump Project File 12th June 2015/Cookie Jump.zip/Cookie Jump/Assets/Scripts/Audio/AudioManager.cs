﻿//Created by Joel Draper for MansionGaming
using UnityEngine;
using System.Collections;

public class AudioManager : MonoBehaviour {

    public bool muteAudio = true;

    public GameObject bgMusic;

	void Start () {
        
	}

    void update()
    {
        if (!muteAudio)
        {
            bgMusic.GetComponent<AudioSource>().Play(); //When game starts, the music starts
        }
        if (muteAudio == true)
        {
            Debug.Log("mute is true");
            bgMusic.GetComponent<AudioSource>().Stop(); //Pauses that god damn annoying music
        }
    }
}

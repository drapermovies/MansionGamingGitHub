#if UNITY_ANDROID || UNITY_IOS

namespace UnityEngine.Advertisements.Optional {
  using System;

  public class ShowOptionsExtended : ShowOptions {
    
    public string gamerSid { get; set; }
    
  }
}

#endif
